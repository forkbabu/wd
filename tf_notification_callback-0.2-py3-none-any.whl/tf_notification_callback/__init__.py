from .main import TelegramCallback, SlackCallback

name = 'tf_notification_callback'
